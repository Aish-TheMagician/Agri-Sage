// AgriSageWireframe.jsx
// React + Tailwind component (single-file) — export default function AgriSageWireframe() { ... }

import React from 'react';

export default function AgriSageWireframe() {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <header className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-600 to-blue-400 flex items-center justify-center text-white font-bold">AS</div>
        <div>
          <h1 className="text-lg font-semibold">AgriSage — Wireframes & SMS UI (High-fidelity mock)</h1>
          <p className="text-sm text-gray-500">Includes SMS conversation flows, IVR wireframe, and screen-level wireframes for onboarding & help</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-white rounded-xl p-5 shadow">
          <div className="space-y-4">
            <div className="border-dashed border-2 border-blue-50 rounded-md p-3">
              <h3 className="font-semibold">1. SMS Conversation Flow (Design goals)</h3>
              <ol className="text-sm text-gray-500 list-decimal ml-5 mt-2">
                <li>Short, action-oriented messages (≤160 chars) — for feature phones.</li>
                <li>Confirm intent in 1 turn if ambiguous.</li>
                <li>Offer "Why?" with 2-3 bullet facts when recommending.</li>
              </ol>
            </div>

            <div className="border-dashed border-2 border-blue-50 rounded-md p-3">
              <h3 className="font-semibold">2. Onboarding Wireframe (sms & IVR)</h3>
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 bg-white rounded border">
                  <strong>SMS Onboarding</strong>
                  <ul className="text-sm text-gray-500 list-disc ml-5 mt-2">
                    <li>User texts: "START"</li>
                    <li>System: "Welcome to AgriSage. Reply 1: Register, 2: Help"</li>
                    <li>User replies: "1" → "Send PIN and village: 1234, Patna"</li>
                  </ul>
                </div>
                <div className="p-3 bg-white rounded border">
                  <strong>IVR Onboarding (2-step)</strong>
                  <div className="mt-2 flex items-center gap-3">
                    <div className="w-20 h-12 bg-blue-50 rounded flex items-center justify-center font-semibold">Call</div>
                    <div>
                      <div className="font-semibold">IVR: "Welcome to AgriSage. Press 1 for Hindi, 2 for English"</div>
                      <div className="text-sm text-gray-500 mt-1">Short prompts, confirm village by voice or keypad</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-dashed border-2 border-blue-50 rounded-md p-3">
              <h3 className="font-semibold">3. Help & Escalation Wireframe</h3>
              <div className="text-sm text-gray-500">If user replies "AGENT" or presses 0 in IVR → route to local extension center contact details + callback request form (SMS).</div>
            </div>

            <div className="border-dashed border-2 border-blue-50 rounded-md p-3">
              <h3 className="font-semibold">4. Message Templates (Examples)</h3>
              <div className="text-sm text-gray-500">
                <div><strong>Query:</strong> "When should I irrigate wheat?"</div>
                <div className="mt-1"><strong>Agent:</strong> "Irrigate tonight. Soil moisture 18%, 3-day forecast: hot. Apply 20 mm. Reply 'WHY' for details."</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow flex flex-col items-center gap-4">
          <div className="w-80 h-[520px] rounded-3xl shadow-lg border p-4 flex flex-col">
            <div className="h-11 flex items-center justify-center font-semibold bg-gradient-to-b from-gray-100 to-white rounded-lg">AgriSage</div>
            <div className="flex-1 p-3 overflow-auto space-y-3">
              <div className="bg-gray-100 text-gray-900 p-3 rounded-lg max-w-[78%]">Namaste! How can I help today? (e.g., irrigation, market price, loan)</div>
              <div className="self-end bg-blue-600 text-white p-3 rounded-lg max-w-[78%]">When should I irrigate my wheat?</div>
              <div className="bg-gray-100 text-gray-900 p-3 rounded-lg max-w-[78%]">Irrigate tonight around 10 PM for 20 minutes. Soil moisture: 18%. 3-day forecast: hot. Reply WHY for details.</div>
              <div className="self-end bg-blue-600 text-white p-3 rounded-lg max-w-[78%]">WHY</div>
              <div className="bg-gray-100 text-gray-900 p-3 rounded-lg max-w-[78%]">Because: 1) Soil moisture 18% (below thresh), 2) 3-day heatwave increases evapotranspiration, 3) Rain chance 5% — so irrigate now.</div>
            </div>
            <div className="h-16 flex items-center gap-2">
              <input className="flex-1 border rounded-lg p-2" placeholder="Type message..." />
              <button className="bg-blue-600 text-white px-4 py-2 rounded-lg">Send</button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 w-full">
            <div className="p-3 border rounded bg-white">
              <strong>Quick Actions (SMS shortcuts)</strong>
              <ul className="text-sm text-gray-500 list-disc ml-5 mt-2">
                <li>1 - Soil status</li>
                <li>2 - Irrigation schedule</li>
                <li>3 - Market price today</li>
                <li>4 - Government schemes</li>
              </ul>
            </div>
            <div className="p-3 border rounded bg-white">
              <strong>Admin Dashboard Widget (concept)</strong>
              <p className="text-sm text-gray-500 mt-2">Shows top queries, response latency, and weekly active users per district.</p>
            </div>
          </div>

          <div className="text-sm text-gray-500">Tip: keep SMS messages concise, confirm intent fast, and always include an explainability "WHY" short bullet when giving advice.</div>
        </div>
      </div>
    </div>
  );
}
